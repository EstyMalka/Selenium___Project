package pages;


public class Constants {
    public final static String CHROME_DRIVER_LOCATION="D:\\Pictures\\Desktop\\chromdrivers\\chromedriver.exe";
    public final static String CONFIG_FILE_LOCATION="C:\\Users\\This_User\\Aoutomation2\\Selenium_Project\\Selenium_Project\\target\\Config.xml";

    public final static String SING_IN_PAGE_TITLE="Sign In | My Account | Next Directory Online";
    public final static String HOME_PAGE_TITLE="\n" + "Next Official Site: Online Fashion, Kids Clothes & Homeware";
    public final static String HOMEPAGE_CATEGORY_TITLE="Furniture & Homeware | Next Home & Garden | Next UK";
    public final static String BEDROOM_CATEGORY_TITLE="Bedroom | Bedroom Accessories & Furnishings | Next Israel";
    public final static String DININGROOM_CATEGORY_TITLE="Dining Room & Kitchen | Next Official";
    public final static String BLANKET_PAGE_TITLE="Blanket from | נקסט ישראל";
    public final static String PAYMENT_PAGE_TITLE="Blanket from | נקסט ישראל";

}


